export const commonParams = {
    g_tk: 0,
    inCharset: 'utf-8',
    outCharset: 'utf-8',
    notice: 0,
    format: 'jsonp'
}
export const option = {
    param: 'jsonpCallback'
}

export const ERR_OK = 0