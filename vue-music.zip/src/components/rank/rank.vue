<template>
    <div>
        排行页面
    </div>
</template>
<script>
    
</script>
<style scope lang="stylus" rel="stylesheet/stylus">

</style>

