<template>
    <div>
        搜索页面
    </div>
</template>
<script>
    
</script>
<style scope lang="stylus" rel="">

</style>

